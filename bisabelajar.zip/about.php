<!DOCTYPE html>
<html lang="en">
<?php include ('layout/head.php') ?>


<body id="about">
    <?php include ('layout/navbar.php') ?>
    <?php include ('layout/headerHalf.php') ?>
    
    <!--?php include ('layout/header.php') ?-->
    <div class="tab tab-content">

		<?php include('pages/about/layout/tentang-kami.php'); ?>  
		<?php include('pages/about/layout/tim-kami.php'); ?>
		<?php include('pages/about/layout/kata-mereka.php'); ?> 
		
	</div>
	<?php include('layout/quote.php'); ?>


	<?php include('layout/footer.php') ?>

	<?php include('layout/foot.php') ?>


</body>

</html>
