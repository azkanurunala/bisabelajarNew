            <div class="row top-padding bottom-padding left-padding right-padding text-left comment-field white-bg">
                <div class="row ">
                    <div class="col-lg-6 text-left">
                        <h5 class="comments bold font-green">Tambahkan Komentar <i class="fa fa-comment"></i></h5>
                    </div>
                    <div class="col-lg-5 text-right no-padding">
                       <h5 class="font-green">sebagai  <i>Azka</i></h5>
                    </div>
                    <div class="col-lg-1 text-right">
                        <img class="image-circle-small" src="img/contributor/001/img.jpg" >
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <textarea name="message" id="message" required="required" class="form-control" rows="5" placeholder="Tulis komentar kamu di sini.."></textarea>
                        </div>
                        <!--div class="form-group">
                            <a type="submit" class="margin-all-narrow login yellow-bg btn btn-primary btn-xl ">Kirim Pesan <i class="left-margin-small fa fa-envelope-o"></i> </a>
                        </div-->
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 text-right">

                        <div class="form-group">
                            <a type="submit" class="padding-all-narrow yellow-bg btn btn-primary btn-xl ">Komentari</a>
                        </div>
                    </div>
                </div>
                <div class="row right-padding ">
                    <div class="col-lg-12 text-left">
                        <h5 class="comments bold font-green">Komentar <i class="fa fa-comments"></i></h5>
                    </div>

                </div>
                <div class="row right-padding ">
                    <div class="col-lg-2 text-left">
                        <img class="image-circle-medium" src="img/contributor/002/img.jpg" >
                    </div>
                    <div class="col-lg-10 text-right">
                        <div class="row bottom-grey-border ">
                            <h5 class="font-green"><i>Dikry</i>, pada 10 Juni 2015 pukul 10.30</h5>
                        </div>
                        <div class="row bottom-grey-border">
                            <p  align="justify" class="no-margin text-justify">
                                Insightful banget deh. Gue gak nyangka kegiatan konsumsi yang gue lakukan 
                                bisa dibuat dengan pendekatan matematik ekonomi, gampang banget lagi 
                                ngertinya. Top banget deh pokoknya BisaBelajar! :D
                            </p>
                        </div>
                    </div>

                </div>

                <div class="row right-padding ">
                    <div class="col-lg-2 text-left">
                        <img class="image-circle-medium" src="img/contributor/005/img.jpg" >
                    </div>
                    <div class="col-lg-10 text-right">
                        <div class="row bottom-grey-border ">
                            <h5 class="font-green"><i>Gandra</i>, pada 9 Juni 2015 pukul 11.30</h5>
                        </div>
                        <div class="row bottom-grey-border">
                            <p  align="justify" class="no-margin text-justify">
                                Wah makasih banget kaaak. Bener-bener ngebantu aku buat 
                                persiapan ujian. Aku jadi ngerti semua materi di kelas :D 
                            </p>
                        </div>
                    </div>

                </div>

            </div>