<div id="submitted" class="modal fade" role="dialog">
      <div class="top-padding modal-dialog text-center">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header left-padding text-left">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title bold font-green ">Jumlah Jawaban Benar: <yellow>8</yellow></h4>
            <h4 class="modal-title bold font-green ">Jumlah Jawaban Salah: <yellow>2</yellow></h4>
          </div>
          <div class="modal-body">
              <div class="row">
                  <div class="col-lg-5">
                  </div>
                  <div class="no-padding col-lg-4 square-circle yell-bg text-center">
                      <h1 class="white-text">80</h1>
                  </div>
                  <div class="col-lg-3">
                  </div>
              </div>
          </div>
          <div class="modal-footer ">
               <div class="bottom-margin row">
                  <div class="col-lg-6 text-left">
                        
                        <a href="#" class="margin-small padding-small share-btn fb-bg btn btn-primary btn-xl ">
                        <i class="social-icon fa fa-share-alt"></i>Share</a>

                        <a href="#" class="margin-small padding-small tweet-btn twitter-bg btn btn-primary btn-xl ">
                        <i class="social-icon fa fa-twitter"></i>Tweet</a>
                    </div>
                  <div class="col-lg-6 text-right">
                        <a href="#" data-dismiss="modal"  class="margin-small padding-small red-bg btn btn-primary btn-xl ">Unduh Soal <i class="social-icon-2 fa fa-download"></i></a>
                  </div>
                </div>

               
                <!--div class="padding-right-narrow text-right col-lg-6 ">
                    <a class="button-gap crud" data-dismiss="modal" href="#">
                    <span class="glyphicon glyphicon-remove"  aria-hidden="true"></span> CANCEL</a>
                </div>
                 <div id = "btnDelete" class="padding-leftt-narrow text-left col-lg-6">
                    <a id="linkDeleteButtonModal" class="delete-button-gap crud"  href="">
                    DELETE <span class="glyphicon glyphicon-ok"  aria-hidden="true"></span></a>
                </div-->
            </div>
          </div>
        </div>

      </div>
</div>

<div id="confirm" class="modal fade" role="dialog">
      <div class="top-padding modal-dialog text-center">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title bold font-green ">Pendaftaran Akun Berhasil!</h4>
          </div>
          <div class="modal-body ">
            <div class="row padding-medium"> 
                    <h4 class="label-login font-green">
                    Link Konfirmasi telah dikirimkan ke emailKamu@domain.com.
                    Buka email kamu untuk melengkapi proses pendaftaran!
                    </h4>
            </div>
            <div class="bottom-margin row">
                  <a href="#" data-dismiss="modal" class="bottom-margin margin-small padding-small red-bg btn btn-primary btn-xl ">Ok</a>
            </div>

          </div>
        </div>

      </div>
</div>

