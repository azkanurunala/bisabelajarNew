        <div id="video" class="tab-pane active">
        <?php include ('tabSwitch.php'); ?>
            <div class="bottom-radius no-top-padding no-top-margin row white-bg top-padding-narrow bottom-margin-narrow">
                    <iframe allow-fullscreen="true" width="790" height="400" src="https://www.youtube.com/embed/vj7XExwChwI"  frameborder="0" allowfullscreen>
                    </iframe>
            
             
                    <div class="col-lg-1 text-left">
                        <img class="image-circle-small" src="img/contributor/001/img.jpg" >
                    </div>
                    <div class="col-lg-5 text-left no-margin no-padding">
                       <h5>oleh  <i>Azka Nurun Ala</i></h5>
                    </div>

            </div>
            <?php include ('pages/ekonomi/layout/socmed.php') ?>
            <div class="row top-green-border bottom-green-border ">
                <div class="col-lg-3 text-left">
                    <a href="#"  class="yellow-outlined yellow-outlined-hover padding-all-narrow btn btn-primary btn-xl ">
                    <i class="social-icon-2 fa fa-chevron-left"></i>SEBELUMNYA</a>
                </div>
                 <div class="col-lg-3 text-center">
                    <a href="#"  class="yell-bg  padding-all-narrow btn btn-primary btn-xl ">
                    IKUTI KELAS<i class="social-icon-2 fa fa-sign-in"></i></a>
                </div>
                 <div class="col-lg-3 text-center">
                    <a href="#"  class="red-bg padding-all-narrow btn btn-primary btn-xl ">
                    UNDUH VIDEO<i class="social-icon-2 fa fa-download"></i></a>
                </div>
                 <div class="col-lg-3 text-right">
                    <a href="#2" data-toggle="tab"  class="yellow-outlined yellow-outlined-hover  padding-all-narrow btn btn-primary btn-xl ">
                    SELANJUTNYA<i class="social-icon-2 fa fa-chevron-right"></i></a>
                </div>
            </div>
            <?php include ('pages/ekonomi/layout/comment.php') ?>


        </div>