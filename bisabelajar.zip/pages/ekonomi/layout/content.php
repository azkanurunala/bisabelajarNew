
    <h3 class="text-center white-text "> Konsumsi, Tabungan, dan Investasi</h3>

    <div class="row tab tab-content text-center top-padding-narrow">

        <?php include ('video.php') ?>
        <?php include ('latihan.php') ?>
        <?php include ('ringkasan.php') ?>

    </div>

