<div  class="tab-pane active">
<?php include ('pages/profil/layout/tabSwitch.php') ?>
<section id="profilku" class="padding-all" >
  <div class="red-bg-3 top-margin-narrow left-margin-narrow right-margin-tiny row top-radius bottom-border-small-2">
          <div   class="  row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="col-lg-12 text-left">

                             <h4 class="bold "><i class="fa fa-user"></i> Profilku</h4>


                </div>                

           
            </div>
    </div>
            <div class="top-margin-narrow left-margin-narrow right-margin-tiny bottom-radius no-top-padding no-top-margin row white-bg top-padding-narrow bottom-margin-narrow">
                <div class="col-lg-7">  
                  <div class="row bottom-border-narrow-2">
                      <div class="col-lg-2 text-left">
                          <img class="image-circle-3" src="img/contributor/001/img.jpg" >
                      </div>
                      <div class="col-lg-5 text-left top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Nama</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Nama Pengguna</bold></td>
                              <td class="td-long"> azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Email</bold></td>
                              <td class="td-long"> nurunalaazka@gmail.com</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Password</bold></td>
                              <td class="td-long"> BaZEnk1234xCoy</td>
                            </tr>
                         </table>
                      </div>


                    </div>

                    <div class="row bottom-padding-narrow top-padding-narrow ">
                      <div class="col-lg-2 text-left">
                          <i class="jumbo font-grey fa fa-share-alt"></i>
                      </div>
                      <div class="col-lg-5 text-left bottom-padding-narrow top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Akun Facebook</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Twitter</bold></td>
                              <td class="td-long"> @Azka_NurunAla</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Instagram</bold></td>
                              <td class="td-long"> @azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun LinkedIn</bold></td>
                              <td class="td-long"> Azka Nurun</td>
                            </tr>
                         </table>
                      </div>

                  </div>
                </div>

                  <div class="col-lg-5 text-left top-padding-narrow">  
                  <div class="row bottom-border-narrow-2">
                  <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Jenis Kelamin</bold></td>

                              <td class="td-long"> Laki-laki</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Tanggal Lahir</bold></td>
                              <td class="td-long"> 18 Desember 1994</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Pendidikan</bold></td>
                              <td class="td-long"> Sekolah Menengah Atas</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Institusi</bold></td>
                              <td class="td-long"> SMA Taruna Nusantara</td>
                            </tr>
                         </table>
                      


                    </div>

                    <div class="row right-padding top-padding-big bottom-padding-narrow text-right">
                                <a href="#"  class="yell-bg  padding-all-narrow btn btn-primary btn-xl ">
                                Edit Profilku <i class="social-icon-2 fa fa-pencil"></i></a>
                    </div>

                    <!--div class="row bottom-padding-narrow top-padding-narrow ">

                         <table class="padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Akun Facebook</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Twitter</bold></td>
                              <td class="td-long"> @Azka_NurunAla</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Instagram</bold></td>
                              <td class="td-long"> @azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun LinkedIn</bold></td>
                              <td class="td-long"> Azka Nurun</td>
                            </tr>
                         </table>
                      

                  </div-->
                </div>
        </div>

    <!--div class="container">
        <div class="row text-center">

          <h4 class="section-heading">Profilku</h4>
          <hr class="primary">
                
        </div>

        <div class="row">
            <div class="col-lg-12">

                        <p class="paragraph" >
                          <img align="left" class="right-margin bottom-margin-narrow img-responsive" src="img/logo.png"/>
                       
                          <?php include('contents/tentang/tentang-kami.txt');?>
                        </p>
           
             

                    
            </div>

        </div>
    </div--> 
   
</section>


    <section id="kelasku" class="class-bg black-bg ">


            <div class="container white-text">

                <div class="row no-padding">
                    <div class=" col-lg-2  col-md-2 text-center wow bounceInLeft">
                        <div class=" no-padding-top padding-narrow service-box">

                            <bold><h3>Kelasku</h3></bold>
                            <img class="icon-medium" src="img/fav.png"/>
                        </div>
                    </div>
                      <div class="col-lg-10 tes text-center wow bounceInRight">
                        <!-- Place somewhere in the <body> of your page -->
                        <div class="no-padding no-margin flexslider ">
                          <ul class="slides">
                           <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-3.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Elastisitas Permintaan dan Penawaran</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-4.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Permintaan, Penawaran, dan Harga Keseimbangan</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-1.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Kegiatan Konsumen dan Produsen</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-2.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Inflasi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-3.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Sistem Ekonomi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-4.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Kebutuhan dan Kelangkaan</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                              
                                <!-- items mirrored twice, total of 12 -->
                            </ul>
                        </div>
                    </div>
                     

                </div>

          </div>

    </section>



<section id="raporku" class="padding-all" >
  <div class="yell-bg-2 top-margin-narrow left-margin-narrow right-margin-tiny row top-radius bottom-border-small-2">
          <div   class="  row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="col-lg-12 text-left">

                             <h4 class="bold "><i class="fa fa-line-chart"></i> Raporku</h4>


                </div>                

           
            </div>
    </div>
            <div class="top-margin-narrow left-margin-narrow right-margin-tiny bottom-radius no-top-padding no-top-margin row white-bg top-padding-narrow bottom-margin-narrow">
                <div class="col-lg-7">  
                  <div class="row bottom-border-narrow-2">
                      <div class="col-lg-2 text-left">
                          <img class="image-circle-3" src="img/contributor/001/img.jpg" >
                      </div>
                      <div class="col-lg-5 text-left top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Nama</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Nama Pengguna</bold></td>
                              <td class="td-long"> azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Email</bold></td>
                              <td class="td-long"> nurunalaazka@gmail.com</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Password</bold></td>
                              <td class="td-long"> BaZEnk1234xCoy</td>
                            </tr>
                         </table>
                      </div>


                    </div>

                    <div class="row bottom-padding-narrow top-padding-narrow ">
                      <div class="col-lg-2 text-left">
                          <i class="jumbo font-grey fa fa-share-alt"></i>
                      </div>
                      <div class="col-lg-5 text-left bottom-padding-narrow top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Akun Facebook</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Twitter</bold></td>
                              <td class="td-long"> @Azka_NurunAla</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Instagram</bold></td>
                              <td class="td-long"> @azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun LinkedIn</bold></td>
                              <td class="td-long"> Azka Nurun</td>
                            </tr>
                         </table>
                      </div>

                  </div>
                </div>

                  <div class="col-lg-5 text-left top-padding-narrow">  
                  <div class="row bottom-border-narrow-2">
                  <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Jenis Kelamin</bold></td>

                              <td class="td-long"> Laki-laki</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Tanggal Lahir</bold></td>
                              <td class="td-long"> 18 Desember 1994</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Pendidikan</bold></td>
                              <td class="td-long"> Sekolah Menengah Atas</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Institusi</bold></td>
                              <td class="td-long"> SMA Taruna Nusantara</td>
                            </tr>
                         </table>
                      


                    </div>

                    <div class="row right-padding top-padding-big bottom-padding-narrow text-right">
                                <a href="#"  class="red-bg  padding-all-narrow btn btn-primary btn-xl ">
                                Edit Profilku <i class="social-icon-2 fa fa-pencil"></i></a>
                    </div>

                </div>
        </div>

 
   
</section>

<section id="lencanaku" class="padding-all" >
  <div class="yell-bg-2 top-margin-narrow left-margin-narrow right-margin-tiny row top-radius bottom-border-small-2">
          <div   class="  row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="col-lg-12 text-left">

                             <h4 class="bold "><i class="fa fa-certificate"></i> Lencanaku</h4>


                </div>                

           
            </div>
    </div>
            <div class="top-margin-narrow left-margin-narrow right-margin-tiny bottom-radius no-top-padding no-top-margin row white-bg top-padding-narrow bottom-margin-narrow">
                <div class="col-lg-7">  
                  <div class="row bottom-border-narrow-2">
                      <div class="col-lg-2 text-left">
                          <img class="image-circle-3" src="img/contributor/001/img.jpg" >
                      </div>
                      <div class="col-lg-5 text-left top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Nama</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Nama Pengguna</bold></td>
                              <td class="td-long"> azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Email</bold></td>
                              <td class="td-long"> nurunalaazka@gmail.com</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Password</bold></td>
                              <td class="td-long"> BaZEnk1234xCoy</td>
                            </tr>
                         </table>
                      </div>


                    </div>

                    <div class="row bottom-padding-narrow top-padding-narrow ">
                      <div class="col-lg-2 text-left">
                          <i class="jumbo font-grey fa fa-share-alt"></i>
                      </div>
                      <div class="col-lg-5 text-left bottom-padding-narrow top-padding-narrow">
                         <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Akun Facebook</bold></td>

                              <td class="td-long"> Azka Nurun Ala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Twitter</bold></td>
                              <td class="td-long"> @Azka_NurunAla</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun Instagram</bold></td>
                              <td class="td-long"> @azkanurunala</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Akun LinkedIn</bold></td>
                              <td class="td-long"> Azka Nurun</td>
                            </tr>
                         </table>
                      </div>

                  </div>
                </div>

                  <div class="col-lg-5 text-left top-padding-narrow">  
                  <div class="row bottom-border-narrow-2">
                  <table class="td-long-extra padding-narrow">
                            <tr>
                              <td class="td-long font-green"><bold>Jenis Kelamin</bold></td>

                              <td class="td-long"> Laki-laki</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Tanggal Lahir</bold></td>
                              <td class="td-long"> 18 Desember 1994</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Pendidikan</bold></td>
                              <td class="td-long"> Sekolah Menengah Atas</td>
                            </tr>
                            <tr>
                              <td class="td-long font-green"><bold>Institusi</bold></td>
                              <td class="td-long"> SMA Taruna Nusantara</td>
                            </tr>
                         </table>
                      


                    </div>

                    <div class="row right-padding top-padding-big bottom-padding-narrow text-right">
                                <a href="#"  class="red-bg  padding-all-narrow btn btn-primary btn-xl ">
                                Edit Profilku <i class="social-icon-2 fa fa-pencil"></i></a>
                    </div>

                </div>
        </div>

 
   
</section>





</div>