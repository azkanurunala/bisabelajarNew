<div id="raporku" class="tab-pane active">
<?php include ('pages/profil/layout/tabSwitch.php') ?>
<section>
    <div class="container">
        <div class="row text-center">

          <h4 class="section-heading">Raporku</h4>
          <hr class="primary">
                
        </div>

    </div> 
   
</section>



<section id="compro" class="black-bg class-bg  ">
  <div class="container">
    <div class="row text-center">
        <iframe allow-fullscreen="true" width="800" height="400" src="https://www.youtube.com/embed/syBv25_aozo" frameborder="0" allowfullscreen>
            
        </iframe>
    </div>
   </div>
</section>

<section>
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12">
                <div class="col-lg-2">
                    <img class="image-circle" src="photos/gandra.jpg">
                </div>
                <div class="green-bg  col-lg-10 top-padding-medium">
                    <p class="text-justify bottom-margin-narrow" >
                        <?php include('contents/tentang/kata-mereka-1.txt');?>
                    </p>
                    <yellow>
                     <p class=" text-right no-margin" >
                        <i><?php include('contents/tentang/km-person-1.txt');?></i>
                    </p></yellow>
                </div>
            </div>
                
        </div>

        <div class="row top-margin text-center">
            <div class="col-lg-12">

                <div class="green-bg  col-lg-10 top-padding-medium">
                   
                    <p class="text-justify bottom-margin-narrow" >
                        <?php include('contents/tentang/kata-mereka-2.txt');?>
                    </p>
                    <yellow>
                     <p class=" text-right no-margin" >
                        <i><?php include('contents/tentang/km-person-2.txt');?></i>
                    </p></yellow>
                </div>
                 <div class="col-lg-2">
                    <img class="image-circle" src="photos/gandra.jpg">
                </div>

            </div>
                
        </div>


    </div> 
   
</section>

</div>