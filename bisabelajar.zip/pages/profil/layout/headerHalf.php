      <section id="footer" class="header-profil white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-lg-1 text-left">
                    
                    
                     <img class="logo-small header-margin img-responsive image-circle-2" src="img/contributor/002/img.jpg" ></a>

                </div>
                <div class="header-margin col-lg-11 text-left">
                     <h3>Profil Siswa </h3>
                </div>
                
            </div>
        </div>
       </div>
    </section>
