<section >
    <div class="container">


        <div class="row">
            <div class="col-lg-8 ">
                            <p align="justify" >
                                <img  align="left" class="img-info-large right-margin-narrow" src="contents/gambar-1.png"/>
                               <?php include('contents/isi-1-1.txt');?>
                            </p>

            </div>
            <div class="all-border left-margin padding-narrow-2 col-lg-3">

                <div class="bottom-border row text-center">
                    
                  <!--img class="icon" src="img/new_info.png"/-->
                  <yellow><h3 class="section-heading"><!--i class="fa fa-newspaper-o"></i--> Artikel Terkait</h3></yellow>

                        
                </div>

                <div class="padding-small row ">         

                            <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                            <div class="row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>



                             
                             <!--div class="row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div-->
                </div>



            </div>

        </div>

        <div class="row top-padding-narrow ">
                
                <div class="col-lg-6 text-left">
                    <a href="#" class="share-btn fb-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-thumbs-up"></i>Like</a>

                    <a href="#" class="share-btn fb-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-share-alt"></i>Share</a>

                    <a href="#" class="tweet-btn twitter-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-twitter"></i>Tweet</a>
                </div>

                <!--div class="col-lg-6 text-right">
                    <a href="#" class="clock-padding green-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-clock-o"></i>00 : 04 : 01</a>
                </div-->
         

            </div>
    </div> 
     


         <div class="row bottom-margin-narrow  top-margin-narrow  ">
            <div class=" col-lg-12 text-center">
              <!--   <div class=" col-lg-3 text-left">
                    <a class="padding-small rounded bold link-info-full yellow-outlined top-margin right-margin  text-left " href="news-content.php" > <span class="top-padding-narrow glyphicon glyphicon-chevron-left" aria-hidden="true"></span> LEBIH BARU </a>
                </div>
                <div class="col-lg-6 text-center"> -->
                   
                      <ul class="pagination">
                        <li><a href="#"><yellow><</yellow></a></li>
                        <li class="active yell-bg-2"><a href="#">1</a></li>
                        <li><a href="#"><yellow>2</yellow></a></li>
                        <li><a href="#"><yellow>3</yellow></a></li>
                        <li><a href="#"><yellow>4</yellow></a></li>
                        <li><a href="#"><yellow>5</yellow></a></li>
                        <li><a href="#"><yellow>></yellow></a></li>
                      </ul>
                    
            <!--     </div>
                <div class=" col-lg-3 text-right">
                    <a class="padding-small rounded bold link-info-full yellow-outlined top-margin right-margin  text-right " href="news-content.php" > LEBIH LAMA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span> </a>
                </div> -->
            </div>
        </div>
</section>
