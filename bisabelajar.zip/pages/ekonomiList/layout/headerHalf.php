      <section id="footer" class="header-class white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-lg-1 text-left">
                     <img class="header-margin logo-small img-responsive" src="img/class/eko.png"/>
                </div>
                <div class="header-margin col-lg-11 text-left">
                     <h3>Ekonomi </h3>
                </div>
                
            </div>
        </div>
       </div>
    </section>
