
    <h3 class="text-center white-text ">Tryout 1 Ekonomi SMA Paket A</h3>

    <div class="row tab tab-content text-center top-padding-narrow">

        <?php include ('soal.php') ?> 
        <?php include ('pembahasan.php') ?> 

    </div>

