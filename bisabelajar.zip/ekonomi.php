<!DOCTYPE html>
<html lang="en">
<?php include ('layout/head.php') ?>


<body id="page-top ">
    <?php include ('layout/navbar.php') ?>
    <?php include ('pages/ekonomi/layout/headerHalf.php'); ?>

<section class="video-bg class-bg">
<div class="container">
	<div class="col-lg-4 ">
		    <?php include ('pages/ekonomi/layout/subjectList.php'); ?>
	</div>
	<div class="col-lg-8 ">
		    <?php include ('pages/ekonomi/layout/content.php'); ?>
	</div>
	<?php include ('pages/ekonomi/layout/submitted.php'); ?>
</div>
</section>
    <?php include('layout/quote.php'); ?>


	<?php include('layout/footer.php') ?>

	<?php include('layout/foot.php') ?>
    <!--?php include ('layout/header.php') ?-->




</body>

</html>
