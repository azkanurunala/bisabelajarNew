<section id="recent-info no-padding no-margin ">
    <div class="container no-padding">
        <div class="row text-center  wow bounceIn">
            
          <!--img class="icon" src="img/new_info.png"/-->
          <!--h3 class="section-heading"><i class="fa fa-newspaper-o"></i> Info Terbaru</h3>
          <hr class="primary"-->
                
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-6   wow bounceInLeft">
                    <div class="row">
                        <h3 class="text-center section-heading">Terbaru </h3>
                        <hr class="primary">
                    </div>
                    <div class="row">
                        <p>
                            <a class="new-info title" href="news-content.php">
                            <h4 class="new-info title"> <?php include ('contents/judul-1.txt'); ?></h4>
                            </a>
                            <a href="news-content.php">
                            <img class="img-info-large" src="contents/gambar-1.png"/>
                            </a>
                            <h5 class="new-info author "><?php include ('contents/penulis-1.txt'); ?></h5>
                            
                           
                            <p class="new-info paragraph" >
                              <?php include('contents/isi-1.txt');?>

                              <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA LEBIH LANJUT <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                            </p>
                        </p>
                    </div>
 
                </div>

                <div class="top-margin  col-lg-6 wow bounceInRight">
                    
                    <div class="bottom-border row">
                        <div class="col-lg-5">
                          
                            <a href="news-content.php">
                            <img class="img-info-large" src="contents/gambar-2.png"/>
                            </a>
                          
                        </div>
                        <div class="no-padding col-lg-7">
                            <a href="news-content.php">
                            <h4 class=" no-padding new-info title"> <?php include ('contents/judul-2.txt'); ?></h4>
                            </a>
                            <h5 class=" new-info author "><?php include ('contents/penulis-2.txt'); ?></h5>
                            <p class="new-info paragraph" >
                               <?php include('contents/isi-2.txt');?>
                                <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA LEBIH LANJUT <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                            </p>
                        </div>
                     </div>

                     <div class="bottom-border row">
                        <div class="col-lg-5">
                          
                            <a href="news-content.php">
                            <img class="img-info-large" src="contents/gambar-3.png"/>
                            </a>
                          
                        </div>
                        <div class="no-padding col-lg-7">
                            <a href="news-content.php">
                            <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                            </a>
                            <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                            <p class="new-info paragraph" >
                               <?php include('contents/isi-3.txt');?>
                                <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA LEBIH LANJUT <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                            </p>
                        </div>
                     </div>

                     <div class=" row">
                        <div class="col-lg-5">
                          
                            <a href="news-content.php">
                            <img class="img-info-large" src="contents/gambar-4.png"/>
                            </a>
                          
                        </div>
                        <div class="no-padding col-lg-7">
                            <a href="news-content.php">
                            <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                            </a>
                            <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                            <p class="new-info paragraph" >
                               <?php include('contents/isi-4.txt');?>
                                <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA LEBIH LANJUT <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                            </p>
                        </div>
                     </div>
                </div>
                    
            </div>

        </div>
    </div> 
       

   
</section>


    <section id="new-classes" class="class-bg black-bg ">


            <div class="container white-text">

                <div class="row no-padding">
                    <div class=" col-lg-2  col-md-2 text-center wow bounceInLeft">
                        <div class=" no-padding-top padding-narrow service-box">

                            <bold><h3>Artikel Favorit</h3></bold>
                            <img class="icon-medium" src="img/fav.png"/>
                        </div>
                    </div>
                      <div class="col-lg-10 tes text-center wow bounceInRight">
                        <!-- Place somewhere in the <body> of your page -->
                        <div class="no-padding no-margin flexslider ">
                          <ul class="slides">

                           <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="contents/gambar-1.png" />
                            <div class="img-video-cover" href="news-content.php">
                            <!--i class="play fa fa-play-circle-o" href="ekonomi.php"></i--></div>
                            <h5 class="white-text  bottom-border-small"><?php include ('contents/judul-1.txt'); ?></h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >oleh Fajar Utomo</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="contents/gambar-2.png" />
                            <div class="img-video-cover" href="news-content.php">
                            <!--i class="play fa fa-play-circle-o" href="ekonomi.php"></i--></div>
                            <h5 class="white-text  bottom-border-small"><?php include ('contents/judul-2.txt'); ?></h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >oleh Masbro Gokil</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="contents/gambar-3.png" />
                            <div class="img-video-cover" href="news-content.php">
                            <!--i class="play fa fa-play-circle-o" href="ekonomi.php"></i--></div>
                            <h5 class="white-text  bottom-border-small"><?php include ('contents/judul-3.txt'); ?></h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >oleh Mbaksis Asik</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="contents/gambar-4.png" />
                            <div class="img-video-cover" href="news-content.php">
                            <!--i class="play fa fa-play-circle-o" href="ekonomi.php"></i--></div>
                            <h5 class="white-text  bottom-border-small"><?php include ('contents/judul-4.txt'); ?></h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >oleh Yuki Sugono</h5>
                            </a>
                          </li>
<!--                           <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="contents/gambar-2.png" />
                            <div class="img-video-cover" href="news-content.php">
                            i class="play fa fa-play-circle-o" href="ekonomi.php"></i</div>
                            <h5 class="white-text  bottom-border-small"><?php include ('contents/judul-1.txt'); ?></h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >oleh Ucrit Crit</h5>
                            </a>
                          </li> -->
                          
                              
                                <!-- items mirrored twice, total of 12 -->
                            </ul>
                        </div>
                    </div>
                     

                </div>

          </div>

    </section>





<section id="news" >
    <div class="container">
        <div class="row">
                  <h3 class="text-center section-heading"><!-- <i class="fa fa-newspaper-o"></i> --> Semua </h3>
                  <hr class="primary">
        </div>
        <div class="row bottom-border no-padding">
            <div class="right-border-small col-lg-6 ">
                <div class="row text-center">
                    
                  <!--img class="icon" src="img/new_info.png"/-->
<!--                   <h3 class="section-heading"><i class="fa fa-newspaper-o"></i> Berita Pendidikan</h3>
                  <hr class="primary"> -->
                        
                </div>

                <div class="row  ">
                    <div class="col-lg-12">
                        <div class="col-lg-12">
                           
                            <div class="row bottom-border">
                                <p>
                                    <a class="new-info title" href="news-content.php">
                                    <h4 class="new-info title"> <?php include ('contents/judul-1.txt'); ?></h4>
                                    </a>
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-1.png"/>
                                    </a>
                                    <h5 class="new-info author "><?php include ('contents/penulis-1.txt'); ?></h5>
                                    
                                   
                                    <p class="new-info paragraph" >
                                      <?php include('contents/isi-1.txt');?>

                                      <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </p>
                            </div>

                            
                            <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-2.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-3.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-3.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>
                            
                             
                             <div class=" row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-3.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-3.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <!--div class="row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div-->

                        </div>
                            
                    </div>

                </div>
            </div>

                <div class="col-lg-6">
                <div class="row text-center">
                    
                  <!--img class="icon" src="img/new_info.png"/-->
                  
                        
                </div>

                <div class="row ">
                    <div class="col-lg-12">
                        <div class="col-lg-12">
                           


                            
                            <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-2.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-3.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-3.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>
                            
                             
                            <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-3.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-3.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>
                            <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-2.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>



                             <div class="bottom-border row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-3.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-3.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>

                             <div class="row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-2.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div>


                             <!--div class="row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div-->

                        </div>
                            
                    </div>

                </div>
            </div>


        </div>

        <div class="row bottom-margin-narrow  top-margin-narrow  ">
            <div class=" col-lg-12 text-center">
              <!--   <div class=" col-lg-3 text-left">
                    <a class="padding-small rounded bold link-info-full yellow-outlined top-margin right-margin  text-left " href="news-content.php" > <span class="top-padding-narrow glyphicon glyphicon-chevron-left" aria-hidden="true"></span> LEBIH BARU </a>
                </div>
                <div class="col-lg-6 text-center"> -->
                   
                      <ul class="pagination">
                        <li><a href="#"><yellow><</yellow></a></li>
                        <li class="active yell-bg-2"><a href="#">1</a></li>
                        <li><a href="#"><yellow>2</yellow></a></li>
                        <li><a href="#"><yellow>3</yellow></a></li>
                        <li><a href="#"><yellow>4</yellow></a></li>
                        <li><a href="#"><yellow>5</yellow></a></li>
                        <li><a href="#"><yellow>></yellow></a></li>
                      </ul>
                    
            <!--     </div>
                <div class=" col-lg-3 text-right">
                    <a class="padding-small rounded bold link-info-full yellow-outlined top-margin right-margin  text-right " href="news-content.php" > LEBIH LAMA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span> </a>
                </div> -->
            </div>
        </div>

    </div>
 


   
</section>