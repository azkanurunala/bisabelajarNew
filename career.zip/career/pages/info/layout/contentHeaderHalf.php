      <section id="footer" class="header-info white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="header-margin col-lg-12 text-left">
                     <h3><i class="fa fa-newspaper-o right-margin-narrow"></i> <?php include ('contents/judul-1.txt'); ?> </h3>
                     <h5 class=" left-margin-medium new-info author "><?php include ('contents/penulis-1.txt'); ?></h5>
                </div>
                
            </div>
        </div>
       </div>
    </section>
