<div id="lencana" class="tab-pane active">
<?php include ('pages/profil/layout/tabSwitch.php') ?>
<section>

    <div class="container">
        <div class="row text-center">

          <h4 class="section-heading">Lencana</h4>
          <hr class="primary">
                
        </div>

        <div class="row">
            <div class="col-lg-12">

                        <p class="paragraph" >
                          <img align="left" class="right-margin bottom-margin-narrow img-responsive" src="img/logo.png"/>
                       
                          <?php include('contents/tentang/tentang-kami.txt');?>
                        </p>
           
             

                    
            </div>

        </div>
    </div> 
   
</section>

<section id="valueKami" class="grey-bg">
    <div class="container">
        <div class="row text-center">



          <div class="col-lg-12">
                <div class="col-lg-3">
                    <img class="value-icon" src="img/mm-icon.png">
                    <h4 class="top-margin-narrow bottom-margin-narrow font-green bold">Materi Melimpah</h4>
                    <p>Kami memiliki sumber materi pelajaran yang melimpah ruah</p>
                </div>
                <div class="col-lg-3">
                    <img class="value-icon" src="img/vm-icon.png">
                    <h4 class="top-margin-narrow bottom-margin-narrow font-green bold">Video Menarik</h4>
                    <p>Dengan Konsep Video yang menarik, belajar pun lebih menyenangkan!</p>
                </div>
                <div class="col-lg-3">
                    <img class="value-icon" src="img/ls-icon.png">
                    <h4 class="top-margin-narrow bottom-margin-narrow font-green bold">Latihan Soal</h4>
                    <p>Latihan soal di setiap bab membuat kamu semakin memahami materi pelajaran</p>
                </div>
                <div class="col-lg-3">
                    <img class="value-icon" src="img/gr-icon.png">
                    <h4 class="top-margin-narrow bottom-margin-narrow font-green bold">Gratis</h4>
                    <p>Ya, kamu bisa mendapatkan semua itu secara cuma-cuma</p>
                </div>
          </div>
                
        </div>

        </div>
 
   
</section>

<section id="compro" class="black-bg class-bg">
  <div class="container">
    <div class="row text-center">
        <iframe allow-fullscreen="true" width="720" height="360" src="https://www.youtube.com/embed/syBv25_aozo" frameborder="0" allowfullscreen>
            
        </iframe>
    </div>
   </div>
</section>
</div>