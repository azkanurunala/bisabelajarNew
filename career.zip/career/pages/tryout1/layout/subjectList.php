<div class="row">
	<a href="kelas.php">
		<h4 class="white-text ">
		<i class="fa fa-chevron-circle-left">
		</i>
			 Kembali ke <yellow>SMA</yellow>

		</h4>
	</a>
</div>
<div class="row">
	<ul class="list-title lists top-padding-narrow bottom-padding-narrow  no-top-margin  no-bottom-margin right-margin top-radius lists">
		<li class=""><a href="#" class="white-text"><h4><i class="fa fa-th-list"></i> Daftar Tryout</h4></a></li>
	</ul>
	<ul class="grey-bg-2 lists padding-all no-top-margin right-margin  bottom-radius lists">
		
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 5 Ekonomi SMA Paket E</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 5 Ekonomi SMA Paket D</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 5 Ekonomi SMA Paket C</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 5 Ekonomi SMA Paket B</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 5 Ekonomi SMA Paket A</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 4 Ekonomi SMA Paket E</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 4 Ekonomi SMA Paket D</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 4 Ekonomi SMA Paket C</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 4 Ekonomi SMA Paket B</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 4 Ekonomi SMA Paket A</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 3 Ekonomi SMA Paket E</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 3 Ekonomi SMA Paket D</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 3 Ekonomi SMA Paket C</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 3 Ekonomi SMA Paket B</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 3 Ekonomi SMA Paket A</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 2 Ekonomi SMA Paket E</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 2 Ekonomi SMA Paket D</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 2 Ekonomi SMA Paket C</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 2 Ekonomi SMA Paket B</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 2 Ekonomi SMA Paket A</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 1 Ekonomi SMA Paket E</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 1 Ekonomi SMA Paket D</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 1 Ekonomi SMA Paket C</h5></a></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Tryout 1 Ekonomi SMA Paket B</h5></a></li>	
		<li ><yellow><a href="#" ><yellow><h5><i class="fa fa-play"></i> Tryout 1 Ekonomi SMA Paket A</h5></yellow></a></yellow></li>

	</ul>
</div>