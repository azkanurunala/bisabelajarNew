<!DOCTYPE html>
<html lang="en">
<?php include ('layout/head.php') ?>


<body id="profil">
    <?php include ('layout/navbar.php') ?>
    <?php include ('pages/profil/layout/headerHalf.php') ?>
    
    <!--?php include ('layout/header.php') ?-->
    <div class="row">

		<?php include('pages/profil/layout/profilku.php'); ?>  
<!--?php include('pages/profil/layout/kelasku.php'); ? -->
		<!--?php include('pages/profil/layout/raporku.php'); ?--> 
		<!--?php include('pages/profil/layout/lencana.php'); ?> -->
		
	</div>
	<?php include('layout/quote.php'); ?>


	<?php include('layout/footer.php') ?>

	<?php include('layout/foot.php') ?>


</body>

</html>
