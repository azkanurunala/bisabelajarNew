<!DOCTYPE html>
<html lang="en">
<?php include ('layout/head.php') ?>


<body id="info">
    <?php include ('layout/navbar.php') ?>
	<?php include ('pages/info/layout/headerHalf.php') ?>

	<?php include('pages/info/layout/content.php'); ?>  

	
	<?php include('layout/quote.php'); ?>


	<?php include('layout/footer.php') ?>

	<?php include('layout/foot.php') ?>


</body>

</html>
