      <section id="footer" class="footer white-text">
       <div class="dark-bg">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-sm-12 col-md-2 text-left">
                     <img class="logo-large img-responsive" src="img/footer_logo.png"/>
                </div>
                <div class="top-margin-narrow col-sm-12 col-md-10 text-left">
                     <!--h4>Sitemap </h4-->
                     
                     <div class="row">
                     
                            <div class="col-sm-12 col-md-2">
                                <a href="kelas.php" class="sitemap page-scroll"><h5>Kelas</h5></a>
                                <a href="tryout.php" class="sitemap page-scroll"><h5>Tryout</h5></a>
                            </div>


                            <div class="col-sm-12 col-md-2">
                                <a href="about.php" class="sitemap page-scroll"><h5>Tentang</h5></a>
                                <a href="hubungi.php" class="sitemap page-scroll"><h5>Hubungi Kami</h5></a>
                            </div>


                            <div class="col-sm-12 col-md-2">
                                <a href="#login" class="sitemap page-scroll"><h5>Login</h5></a>
                                <a href="#register" class="sitemap page-scroll"><h5>Register</h5></a>
                            </div>


                            <div class="col-sm-12 col-md-2">
                                <a href="info.php" class="sitemap page-scroll"><h5>Info</h5></a>
                                <a href="#" class="sitemap page-scroll"><h5>Cari Kelas</h5></a>
                            </div>

                     </div>

                     <br>

                      <div class="row">
                     
                            <div class="col-sm-12 col-md-2">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-facebook fb social-icon"></i> Bisa Belajar
                                </a>

                            </div>


                            <div class="col-sm-12 col-md-2">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-twitter twitter social-icon"></i> @BisaBelajar
                                </a>

                            </div>

                             <div class="col-sm-12 col-md-2">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-youtube-play youtube social-icon"></i> Bisa Belajar
                                </a>

                            </div>


                     </div>
                     
                </div>
                
            </div>
        </div>
       </div>
    </section>
