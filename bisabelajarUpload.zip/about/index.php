<!DOCTYPE html>
<html lang="en">
<?php include ('../layout/head.php'); ?>


<body id="page-top">
<?php include ('../layout/navbar.php'); ?>
<?php include ('../layout/header.php'); ?>

    

<?php include('../layout/quote.php'); ?>


<?php include('../layout/footer.php'); ?>

<?php include('../layout/foot.php'); ?>


</body>

</html>
