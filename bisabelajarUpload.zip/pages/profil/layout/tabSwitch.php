
    <nav id="mainNav" class="text-center navbar tab-switch-default ">
        <div class="container container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="col-sm-12 col-md-4">
            </div>
            <div class="col-sm-12 col-md-8 text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
 
                <ul class="nav navbar-nav">
                    <li class="tab-option">
                        <a  class="link-tab page-scroll"  href="#profilku"><h4 class="bold font-green">Profilku</h4></a>
                    </li>
                    <li class="tab-option">
                        <a  class="link-tab page-scroll"  href="#kelasku" ><h4 class="bold font-green">Kelasku</h4></a>
                    </li >
                    <li class="tab-option" >
                        <a class="link-tab page-scroll"  href="#raporku"><h4 class="bold font-green">Raporku</h4></a>
                    </li>
                    <li class="tab-option" >
                        <a class="link-tab page-scroll"  href="#lencanaku"><h4 class="bold font-green">Lencana</h4></a>
                    </li>
                   
                </ul>

<!--                 <ul class="nav navbar-nav">
                    <li class="tab-option">
                        <a  class="link-tab page-scroll"  href="#profilku"><h4 class="bold font-green">Profilku</h4></a>
                    </li>
                    <li class="tab-option">
                        <a  class="link-tab page-scroll"  href="#kelasku" ><h4 class="bold font-green">Kelasku</h4></a>
                    </li >
                    <li class="tab-option" >
                        <a class="link-tab"  href="#raporku"><h4 class="bold font-green">Raporku</h4></a>
                    </li>
                    <li class="tab-option" >
                        <a class="link-tab"  href="#lencana"><h4 class="bold font-green">Lencana</h4></a>
                    </li>
                   
                </ul> -->
           
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   