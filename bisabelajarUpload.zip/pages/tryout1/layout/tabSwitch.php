
    <div class="row left-margin-narrow left-padding-narrow">
    <nav id="mainNav" class="top-radius text-center navbar shadow-bottom tab-switch-default" >

            <div   class=" row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                <div class="col-sm-12 col-md-4">
                </div>
                <div class="col-sm-12 col-md-8">
                <ul class="nav navbar-nav" >

                    <li class="tab-option">
                        <a  class="link-tab" data-toggle="tab" href="#soal">
                        <h4 class="bold font-green"><i class="fa fa-pencil-square-o"></i> Soal</h4>
                        </a>
                    </li>
                    <li class="tab-option">
                        <a  class="link-tab" data-toggle="tab" href="#pembahasan">
                        <h4 class="bold font-green"><i class="fa fa-paper-plane"></i> Pembahasan</h4>
                        </a>
                    </li>


                </ul>
                </div>                

           
            </div>


        <!-- /.container-fluid -->
    </nav>
    </div>


   