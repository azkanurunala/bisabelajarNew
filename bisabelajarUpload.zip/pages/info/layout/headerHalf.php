      <section id="footer" class="header-info white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-sm-12 col-md-1 text-left">
                     <img class="header-margin logo-small img-responsive" src="img/info_logo.png"/>
                </div>
                <div class="header-margin col-sm-12 col-md-11 text-left">
                     <h3>Info </h3>
                </div>
                
            </div>
        </div>
       </div>
    </section>
