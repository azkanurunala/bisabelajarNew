<?php

$core_path = dirname(__FILE__);

include("{$core_path}/inc/csv.inc.php");
include("{$core_path}/inc/users.inc.php");

?>