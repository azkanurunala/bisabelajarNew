      <section id="footer" class="footer white-text">
       <div class="dark-bg">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-sm-12 col-md-2 text-left">
                     <a href="../index.php"><img class="logo-large img-responsive" src="img/footer_logo.png"/></a>
                </div>
                <div class="top-margin-narrow col-sm-12 col-md-10 text-left">
                     <!--h4>Sitemap </h4-->
                     
                     <div class="row">
                     
                            <div class="col-sm-12 col-md-3">
                                <a href="#animator" class="sitemap page-scroll"><h4>Animator</h4></a>
                                
                            </div>


                            <div class="col-sm-12 col-md-4">
                                <a href="#director" class="sitemap page-scroll"><h4>Content Strategist</h4></a>
                               
                            </div>


                            <div class="col-sm-12 col-md-3">
                                <a href="#teacher" class="sitemap page-scroll"><h4>Teacher</h4></a>
                                
                            </div>



                     </div>

                     <br>

                      <div class="row">
                     
                            <div class="col-sm-12 col-md-3">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-facebook fb social-icon"></i> Bisa Belajar
                                </a>

                            </div>


                            <div class="col-sm-12 col-md-4">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-twitter twitter social-icon"></i> @BisaBelajar
                                </a>

                            </div>

                             <div class="col-sm-12 col-md-3">
                                <a  href="#" class="sitemap page-scroll">
                                <i class="fa fa-youtube-play youtube social-icon"></i> Bisa Belajar
                                </a>

                            </div>


                     </div>
                     
                </div>
                
            </div>
        </div>
       </div>
    </section>
