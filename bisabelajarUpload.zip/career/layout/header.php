
<header>
    <div class="">
        <div class="header-content ">
            <div class="header-content-inner">
                <!-- <img class="tiny-icon " src="img/footer_logo.png"/> -->
                <br><br><br>
                <p  ><br><br>
                Melalui Bisabelajar.com, kami mengembangkan sebuah media 
                tempat semua orang belajar. <br>

                Kami memanggil anak-anak muda yang luar biasa untuk bergabung bersama kami sebagai:

                <!-- Ayo berkarir bersama BisaBelajar sebagai -->
                </p>
                <div class="row text-center">
                <div class="col-sm-12 col-md-1">
                </div>
                <div class="col-sm-12 col-md-3 icon-bg">
                    <a class="page-scroll" href="#animator"><img src="img/hiring/animator.png" class="job-icon"/></a>
                </div>

                <div class="col-sm-12 col-md-3 icon-bg-special">
                    <a class="page-scroll" href="#director"><img src="img/hiring/director.png" class="job-icon-special"/></a>
                </div>


                <div class="col-sm-12 col-md-3 icon-bg">
                    <a class="page-scroll" href="#teacher"><img src="img/hiring/teacher.png" class="job-icon"/></a>
                </div>
                </div>

                <a href="#form" data-toggle="modal" data-target="#form" class="top-margin yellow-bg btn btn-primary btn-xl ">Mulai Berkarir</a>

                <p clas="top-margin"> <br><yellow>Batas Pendaftaran : 23 Agustus 2015</yellow></p>
            </div>
        </div>
    </div>
</header>

