      <section id="footer" class="header-about white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-sm-12 col-md-1 text-left">
                     <img class="header-margin logo-small img-responsive" src="img/about.png"/>
                </div>
                <div class="header-margin col-sm-12 col-md-11 text-left">
                     <h3>Tentang Kami </h3>
                </div>
                
            </div>
        </div>
       </div>
    </section>
