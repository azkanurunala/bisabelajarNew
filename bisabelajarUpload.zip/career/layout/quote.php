      <!--section id="footer" class="quote white-text">
 
        <div class=" no-padding container">
            <div class="text-left">
                
               
                <div class="top-margin-narrow col-sm-12 col-md-10 text-left">
                     
                     
                     <div class="row">
                            
                            <h4><i>" Ing Ngarsa Sung Tuladha, Ing Madya Mangun Karsa, Tut Wuri Handayani "</i></h4>
                            <h5>- Ki Hajar Dewantara -</h5>

                     </div>

                     <br>

                     
                     
                </div>
                 <div class="col-sm-12 col-md-2 text-center">
                     <div class="photo-border text-center">
                     <div class="photo-quote text-center"></div>
                     </div>
                     
                     
                </div>
                
            </div>
        </div>

    </section-->
