<!DOCTYPE html>
<html lang="en">

<?php include ('layout/head.php') ?>


<body id="home">
    <?php include ('layout/navbar.php') ?>
    <?php include ('layout/header.php') ?>
    <?php include ('layout/animator.php') ?>
    <?php include ('layout/director.php') ?>
    <?php include ('layout/teacher.php') ?>
    <?php include ('layout/form.php') ?>
    <?php include('layout/footer.php') ?>

    <?php include('layout/foot.php') ?>


</body>

</html>
